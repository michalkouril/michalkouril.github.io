#!/usr/bin/env python3
"""AP-mode firmware upload for BloomSky SKY2 (TCP port 14095).

Fixed version of factory_mode_upgrade.py:
  * cmd 6 reserves the real image size, as the HTTP update does. The old script
    sent 0 or 1, so writes past the reserved space failed silently and the
    bootloader then copied garbage over the app.
  * Every chunk's reply is checked. A rejected chunk does not advance the
    device's write offset, so it can be resent safely.
  * The reboot (cmd 10) is only sent after every chunk was accepted.
  * TCP_NODELAY plus a pause between header and data, because the firmware
    discards any data that arrives in the same packet as the header.

The device has no read-back on this path, so a reply only confirms the chunk's
MD5, not the flash write. Test on a device you can recover over SWD.

If a run aborts, reboot the device before retrying: cmd 6 does not reset the
write offset. The boot settings are unchanged until cmd 10 is sent.
"""
import argparse
import hashlib
import re
import socket
import struct
import sys
from pathlib import Path
from time import sleep

DEFAULT_DIR = Path(__file__).resolve().parents[2] / '04-firmware-re/firm/skyfm/2.0.12'
PORT = 14095
CHUNK_SIZE = 0x2800       # the firmware's receive buffer; larger chunks overflow it
APP_ADDRS = {'sky1': 0x0800c000, 'sky2': 0x08004000}
MAGIC = b'BLOOMSKY'
CMD_ALLOCATE = 6
CMD_CHUNK = 8
CMD_REBOOT = 10
REPLY_SIZE = 16
REPLY_TIMEOUT = 30        # the device gives up on a partial chunk after 5s
HEADER_DATA_GAP = 0.2
CHUNK_GAP = 1.0
CHUNK_ATTEMPTS = 3


class UploadError(Exception):
    pass


def load_image(directory, model='sky2'):
    """Return the BSFW pieces joined in numeric order, after checking them."""
    pieces = {}
    for path in Path(directory).iterdir():
        match = re.fullmatch(r'BSFW(\d+)', path.name)
        if match:
            pieces[int(match.group(1))] = path
    if not pieces:
        raise UploadError(f'no BSFW files in {directory}')
    if sorted(pieces) != list(range(len(pieces))):
        raise UploadError(f'BSFW numbering has gaps: {sorted(pieces)}')

    image = b''.join(pieces[i].read_bytes() for i in range(len(pieces)))
    check_image(image, model)
    return image


def check_image(image, model='sky2'):
    """Refuse anything the model's bootloader could not load in full."""
    if image[:4] != b'\x7fELF':
        raise UploadError('image is not an ELF file')

    phoff = struct.unpack_from('<I', image, 28)[0]
    phentsize, phnum = struct.unpack_from('<HH', image, 42)
    first_load = None
    for i in range(phnum):
        p_type, p_offset, _, p_paddr, p_filesz = struct.unpack_from(
            '<5I', image, phoff + i * phentsize)
        if p_offset + p_filesz > len(image):
            raise UploadError(f'segment {i} extends past the end of the image')
        if p_type == 1 and first_load is None:
            first_load = p_paddr

    if first_load != APP_ADDRS[model]:
        raise UploadError(
            f'image loads at {first_load:#x}, {model} expects {APP_ADDRS[model]:#x}')


def connect(host):
    sock = socket.create_connection((host, PORT), timeout=REPLY_TIMEOUT)
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    return sock


def read_reply(sock, cmd):
    """Return True if the device accepted cmd, False if it rejected it."""
    reply = b''
    try:
        while len(reply) < REPLY_SIZE:
            data = sock.recv(REPLY_SIZE - len(reply))
            if not data:
                raise UploadError(f'cmd {cmd}: connection closed, got {reply!r}')
            reply += data
    except socket.timeout:
        raise UploadError(f'cmd {cmd}: no reply, got {reply!r}') from None

    code, value = struct.unpack_from('<II', reply, 8)
    if reply[:8] != MAGIC or code != cmd + 1:
        raise UploadError(f'cmd {cmd}: unexpected reply {reply!r}')
    return value == 1


def header(cmd, value):
    return MAGIC + struct.pack('<II', cmd, value)


def allocate(host, total):
    with connect(host) as sock:
        sock.sendall(header(CMD_ALLOCATE, total))
        if not read_reply(sock, CMD_ALLOCATE):
            raise UploadError(f'device refused to reserve {total} bytes')


def send_chunk(host, chunk):
    md5 = hashlib.md5(chunk).hexdigest().encode()
    with connect(host) as sock:
        sock.sendall(header(CMD_CHUNK, len(chunk)) + md5)
        sleep(HEADER_DATA_GAP)
        sock.sendall(chunk)
        return read_reply(sock, CMD_CHUNK)


def upload(host, image):
    chunks = [image[i:i + CHUNK_SIZE] for i in range(0, len(image), CHUNK_SIZE)]

    print(f'Reserving {len(image)} bytes')
    allocate(host, len(image))

    for number, chunk in enumerate(chunks, 1):
        for attempt in range(1, CHUNK_ATTEMPTS + 1):
            print(f'Chunk {number}/{len(chunks)} ({len(chunk)} bytes), attempt {attempt}')
            if send_chunk(host, chunk):
                break
            sleep(CHUNK_GAP)
        else:
            raise UploadError(f'chunk {number} rejected {CHUNK_ATTEMPTS} times')
        sleep(CHUNK_GAP)

    print('All chunks accepted, rebooting into the bootloader copy')
    with connect(host) as sock:
        sock.sendall(header(CMD_REBOOT, 0))


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('directory', nargs='?', default=DEFAULT_DIR,
                        help='folder holding the BSFW files (default: %(default)s)')
    parser.add_argument('--host', default='192.168.2.2')
    parser.add_argument('--model', choices=APP_ADDRS, default='sky2',
                        help='device model the image must match (default: %(default)s)')
    parser.add_argument('--dry-run', action='store_true',
                        help='check the image and stop without connecting')
    args = parser.parse_args()

    try:
        image = load_image(args.directory, args.model)
        print(f'{args.directory}: {len(image)} bytes, '
              f'md5 {hashlib.md5(image).hexdigest()}')
        if not args.dry_run:
            upload(args.host, image)
    except (UploadError, OSError) as error:
        print(f'FAILED, reboot not sent: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
