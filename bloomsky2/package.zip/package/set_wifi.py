#!/usr/bin/env python3
"""Send Wi-Fi settings to a SKY1 or SKY2 running the patched elven firmware.

The device must be in AP mode, with this computer on its SKY_... network. It
saves the settings and returns what it stored, and this script compares the two.
A match shows the settings were saved, not that they suit your network, so
still check that the device joins after a reboot.

Exit codes: 0 matched, 1 failed to send, 2 no reply, 3 saved settings differ.

Omit --password to be prompted, which keeps it out of your shell history.
"""
import argparse
import getpass
import socket
import struct
import sys

PORT = 14095
MAGIC = b'BLOOMSKY'
CMD_SET_WIFI = 11
ENTRY_SIZE = 0x79
REPLY_TIMEOUT = 30

SSID_MAX = 31      # SKY2 treats a stored SSID of 32 or more characters as invalid
BAND_2_4GHZ = 1

# wiced_security_t values
SECURITY = {
    'open': 0,
    'wpa-tkip': 0x00200002,
    'wpa-aes': 0x00200004,
    'wpa2-aes': 0x00400004,
    'wpa2-tkip': 0x00400002,
    'wpa2-mixed': 0x00400006,
}

# Ranges within the entry, used to name a difference without printing its value.
FIELDS = [
    ('SSID', 0x00, 0x21),
    ('BSSID', 0x21, 0x27),
    ('signal, rate and network type', 0x27, 0x2e),
    ('security', 0x2e, 0x32),
    ('channel', 0x32, 0x33),
    ('band', 0x33, 0x34),
    ('reserved', 0x34, 0x38),
    ('password', 0x38, ENTRY_SIZE),
]


def build_entry(ssid, password, security):
    """Return stored_ap_list[0]: BSSID, channel and other fields stay zero."""
    ssid = ssid.encode()
    password = password.encode()
    if not 1 <= len(ssid) <= SSID_MAX:
        raise ValueError(f'SSID must be 1 to {SSID_MAX} bytes')
    if security == 'open':
        if password:
            raise ValueError('an open network takes no password')
    elif not 8 <= len(password) <= 63:
        raise ValueError('password must be 8 to 63 bytes')

    entry = bytearray(ENTRY_SIZE)
    entry[0] = len(ssid)
    entry[1:1 + len(ssid)] = ssid
    struct.pack_into('<I', entry, 0x2e, SECURITY[security])
    entry[0x33] = BAND_2_4GHZ
    entry[0x38] = len(password)
    entry[0x39:0x39 + len(password)] = password
    return bytes(entry)


def send(host, entry):
    """Send the entry and return the stored copy, or fewer bytes if cut short."""
    # One send, because the firmware only reads the first packet of a connection.
    packet = MAGIC + struct.pack('<II', CMD_SET_WIFI, len(entry)) + entry
    reply = b''
    with socket.create_connection((host, PORT), timeout=REPLY_TIMEOUT) as sock:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.sendall(packet)
        try:
            while len(reply) < len(entry):
                data = sock.recv(len(entry) - len(reply))
                if not data:
                    break
                reply += data
        except socket.timeout:
            pass
    return reply


def differing_fields(sent, stored):
    return [name for name, start, end in FIELDS if sent[start:end] != stored[start:end]]


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('--ssid', required=True)
    parser.add_argument('--password')
    parser.add_argument('--security', choices=SECURITY, default='wpa2-aes')
    parser.add_argument('--host', default='192.168.2.2')
    args = parser.parse_args()

    password = args.password
    if password is None:
        password = '' if args.security == 'open' else getpass.getpass('Wi-Fi password: ')

    try:
        entry = build_entry(args.ssid, password, args.security)
        stored = send(args.host, entry)
    except (ValueError, OSError) as error:
        print(f'FAILED: {error}', file=sys.stderr)
        return 1

    if len(stored) != ENTRY_SIZE:
        print(f'FAILED: expected {ENTRY_SIZE} bytes back, got {len(stored)}. The save is '
              'unconfirmed. Unpatched firmware sends no reply.', file=sys.stderr)
        return 2

    if stored != entry:
        print('FAILED: saved settings differ in: ' + ', '.join(differing_fields(entry, stored)),
              file=sys.stderr)
        return 3

    print(f'OK: saved settings match "{args.ssid}" ({args.security}).')
    print('Now power-cycle without holding the button and check that it joins.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
